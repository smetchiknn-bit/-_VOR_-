# ✅ Чек-лист для создания проекта !_VOR_!

## 📋 Шаг 1: Создание репозитория на GitHub

- [ ] Зайти на github.com
- [ ] Нажать "+" → "New repository"
- [ ] Имя репозитория: `!_VOR_!`
- [ ] Описание: `Генератор ВОР - ведомость объёмов работ`
- [ ] Выбрать Public или Private
- [ ] ❌ НЕ добавлять README (уже есть)
- [ ] ❌ НЕ добавлять .gitignore (уже есть)
- [ ] ❌ НЕ добавлять license
- [ ] Нажать "Create repository"

---

## 📦 Шаг 2: Загрузка файлов

### Метод 1: Через веб-интерфейс GitHub (проще)

- [ ] На странице репозитория нажать "uploading an existing file"
- [ ] Загрузить ВСЕ 22 файла из списка ниже
- [ ] Нажать "Commit changes"

### Метод 2: Через Git (профессиональнее)

```bash
# Клонировать репозиторий
git clone https://github.com/ВАШ_USERNAME/!_VOR_!.git
cd !_VOR_!

# Скопировать все файлы из текущего проекта
# (используйте файловый менеджер)

# Добавить все файлы
git add .

# Коммит
git commit -m "Initial commit: Генератор ВОР"

# Отправить на GitHub
git push origin main
```

---

## 📁 Полный список файлов (22 файла)

### Корневые файлы (10 файлов):
- [ ] `.gitignore`
- [ ] `README.md`
- [ ] `DEPLOYMENT.md`
- [ ] `CHECKLIST.md` (этот файл)
- [ ] `app.py`
- [ ] `index.html`
- [ ] `package.json`
- [ ] `package-lock.json`
- [ ] `requirements.txt`
- [ ] `tsconfig.json`
- [ ] `vercel.json`
- [ ] `vite.config.js`

### Исходный код (12 файлов):
- [ ] `src/main.tsx`
- [ ] `src/index.css`
- [ ] `src/App.tsx`
- [ ] `src/components/ui.tsx`
- [ ] `src/components/reference.tsx`
- [ ] `src/components/results.tsx`
- [ ] `src/components/pythonPanel.tsx`
- [ ] `src/lib/vor.ts`
- [ ] `src/lib/excelIo.ts`
- [ ] `src/lib/demo.ts`
- [ ] `src/lib/prompt.ts`
- [ ] `src/lib/streamlit.ts`

---

## 🚀 Шаг 3: Развёртывание на Vercel

- [ ] Зайти на vercel.com
- [ ] Войти через GitHub
- [ ] Нажать "Add New..." → "Project"
- [ ] Найти репозиторий `!_VOR_!`
- [ ] Нажать "Import"
- [ ] Проверить настройки:
  - Framework Preset: `Vite`
  - Build Command: `npm run build`
  - Output Directory: `dist`
  - Install Command: `npm install`
- [ ] Нажать "Deploy"
- [ ] Дождаться завершения (~15-30 секунд)
- [ ] Скопировать URL проекта

---

## ✅ Шаг 4: Проверка работоспособности

- [ ] Главная страница загружается
- [ ] Видна заставка "ГЕНЕРАТОР·ВОР"
- [ ] Можно загрузить демо-данные
- [ ] Можно загрузить свои Excel-файлы
- [ ] Формируется ВОР.xlsx
- [ ] Скачивается файл с форматированием
- [ ] Строки "Спецификация" выделены серым (#D9D9D9) и полужирным

---

## 🎯 Готово!

Если все галочки поставлены - проект успешно развёрнут! 🎉

---

## 📞 Если возникли проблемы

1. Проверьте логи деплоя на Vercel
2. Убедитесь, что все 22 файла загружены
3. Проверьте настройки проекта на Vercel
4. Обратитесь к файлу `DEPLOYMENT.md` для подробностей
